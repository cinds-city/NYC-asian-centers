#Installing Packages
install.packages("tidyverse")
install.packages("janitor")
install.packages("ggplot2")

library(tidyverse)
library(janitor)
library(ggplot2)
##############################################################################

#Reading NYC Asian Ethnic Dataset from Census Bureau
data <- read.csv("Asian.csv")

#Cleaning Column Names

clean_data <- data %>% 
  clean_names() %>% 
  rename(Total_pop = dp05_0001e)

#Selecting ethnic groups, inclduing both single-race and multiracial categories
export <- clean_data %>% 
  select(geo_id,popgroup_label,Total_pop) %>% 
  filter(popgroup_label %in% c("Asian Indian alone or in any combination",
         "Bangladeshi alone or in any combination","Cambodian alone or in any combination",
         "Chinese, except Taiwanese alone or in any combination", "	
Taiwanese alone or in any combination", "Filipino alone or in any combination",
        "Indonesian alone or in any combination","Japanese alone or in any combination",
        "Korean alone or in any combination","Laotian alone or in any combination","Malaysian alone or in any combination",
        "Pakistani alone or in any combination", "Sri Lankan alone or in any combination",
        "Thai alone or in any combination","Vietnamese alone or in any combination"))

# Save the 'export' dataset to a CSV file for QGIS
write.csv(export, "export_ethnic_groups.csv", row.names = FALSE)


#Showcasing the largest Asian ethnic group in NYC for a graph

graph <- clean_data %>% 
  select(geo_id,popgroup_label,Total_pop) %>% 
  filter(popgroup_label %in% c("Asian Indian alone or in any combination",
                               "Bangladeshi alone or in any combination","Cambodian alone or in any combination",
                               "Chinese, except Taiwanese alone or in any combination", "	
Taiwanese alone or in any combination", "Filipino alone or in any combination",
                               "Indonesian alone or in any combination","Japanese alone or in any combination",
                               "Korean alone or in any combination","Laotian alone or in any combination","Malaysian alone or in any combination",
                               "Pakistani alone or in any combination", "Sri Lankan alone or in any combination",
                               "Thai alone or in any combination","Vietnamese alone or in any combination")) %>% 
  filter(geo_id == "0400000US36") %>% 
  arrange(desc(Total_pop))

# Save the 'graph' dataset to a CSV file
write.csv(graph, "graph_largest_ethnic_groups.csv", row.names = FALSE)




